livery = {
	{"A-10C_PAINT_1-a", 0 ,"des-punisher-a",true};
	{"A-10C_PAINT_1-b", 0 ,"des-punisher-b",true};
	{"A-10C_PAINT_1-c", 0 ,"des-punisher-c",true};
	{"A-10C_PAINT_1-d", 0 ,"des-punisher-d",true};
	{"A-10C_PAINT_1-e", 0 ,"des-punisher-e",true};
	{"A-10C_PAINT_1-f", 0 ,"des-punisher-f",true};
	{"A-10C_PAINT_1-g", 0 ,"des-punisher-g",true};
	{"A-10C_PAINT_1-h", 0 ,"des-punisher-h",true};
	{"A-10C_PAINT_1-i", 0 ,"des-punisher-i",true};
	{"A-10C_PAINT_1-j", 0 ,"des-punisher-j",true};
	{"A-10C_PAINT_1-k", 0 ,"des-punisher-k",true};
	{"A-10C_PAINT_1-L", 0 ,"des-punisher-l”,true};
	{"A-10_Number", 0 ,"TactNumbers-USAF-Light_black",true};
	{"A-10_Number_Noze_F", 0 ,"TactNumbers-USAF-Light_black",true};
	{"A-10_Number_Noze_T", 0 ,"empty",true};
	{"A-10_Number_Wheel", 0 ,"empty",true};

}
countries = {"USA"}