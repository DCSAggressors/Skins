livery = {
	{"A-10C_PAINT_1-a", 0 ,"punisher-a",false};
	{"A-10C_PAINT_1-b", 0 ,"punisher-b",false};
	{"A-10C_PAINT_1-c", 0 ,"punisher-c",false};
	{"A-10C_PAINT_1-d", 0 ,"punisher-d",false};
	{"A-10C_PAINT_1-e", 0 ,"punisher-e",false};
	{"A-10C_PAINT_1-f", 0 ,"punisher-f",false};
	{"A-10C_PAINT_1-g", 0 ,"punisher-g",false};
	{"A-10C_PAINT_1-h", 0 ,"punisher-h",false};
	{"A-10C_PAINT_1-i", 0 ,"punisher-i",false};
	{"A-10C_PAINT_1-j", 0 ,"punisher-j",false};
	{"A-10C_PAINT_1-k", 0 ,"punisher-k",false};
	{"A-10C_PAINT_1-L", 0 ,"punisher-L",false};
	{"A-10_Number", 0 ,"TactNumbers-USAF-Light_black",true};
	{"A-10_Number_Noze_F", 0 ,"TactNumbers-USAF-Light_black",true};
	{"A-10_Number_Noze_T", 0 ,"empty",true};
	{"A-10_Number_Wheel", 0 ,"empty",true};

}
countries = {"USA"}