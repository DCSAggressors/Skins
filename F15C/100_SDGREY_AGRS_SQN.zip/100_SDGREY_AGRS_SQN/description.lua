livery = {
	{"f15nose", 0 ,"f15_nose",false};
	{"f15nose", 3 ,"f15_decol_empty",true};
	{"f15bottom", 0 ,"f15_bottom",false};
	{"f15bottom", 2 ,"f15_bottom_spec",false};
	{"f15bottom", 3 ,"f15_decol_empty",true};
	{"f15centr", 0 ,"f15_centr",false};
	{"f15wingl", 0 ,"f15_wing_l",false};
	{"f15wingl", 3 ,"f15_decol_empty",true};
	{"f15wingr", 0 ,"f15_wing_r",false};
	{"f15stab", 0 ,"f15_stab_v",false};
	{"f15stab", 3 ,"f15_decol_empty",true};
	{"f15numbers", 0 ,"f15_numbers",true};
	{"pilot_F15_patch", 0 ,"pilot_f15_patch_AGRS_sqdn",false};
	{"pilot_F15_00_body", 0 ,"pilot_f15_00_a",true};
	{"f15PTB", 0 ,"f15_PTB",false};
	{"f15PTB", 2 ,"f15_ptb_spec",false};
	

}

countries = {"USA"}

